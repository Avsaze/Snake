/*This is the class that has all the info on the head of the snake.
 * Authors: Trevor Horine, Nick Rich
 * Date: 6/15/17 */

import java.awt.Color;
import java.awt.Graphics;

public class Snake {//creating the class for the snake head
	int x;
	int y;
	int width = 10;
	int height = 10;
	int speed;
	public Snake (int newx, int newy, int newspeed) {
		x = newx;
		y = newy;
		speed = newspeed;
		
	}
	public void paintMe(Graphics g) {//painting the snake
		g.setColor(Color.GREEN);
		g.fillRect(x, y, width, height);
	}
	public int getX() {//getters and setters
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
}