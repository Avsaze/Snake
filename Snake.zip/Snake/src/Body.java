/*This is the class that has all the info on the body parts of the snake.
 * Authors: Trevor Horine, Nick Rich
 * Date: 6/15/17 */

import java.awt.Color;
import java.awt.Graphics;

public class Body {//creating the snake body class
	int x;
	int y;
	int length;
	int width = 10;
	int height = 10;
	public Body (int newx, int newy) {
		x = newx;
		y = newy;
	}
	public void paintMe(Graphics g) {//painting the body
		g.setColor(Color.GREEN);
		g.fillRect(x, y, width, height);
	}
	public int getX() {//getter and setter
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
}